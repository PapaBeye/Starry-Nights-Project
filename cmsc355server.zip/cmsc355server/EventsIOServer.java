package cmsc355server;


import java.net.*;
import java.io.*;

public class EventsIOServer {

	public static void main(String[] args) {
		try {
			ServerSocket s = new ServerSocket(4435);
			while (true) {
				Socket cs = s.accept();
				new Thread(new clworker(cs)).start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

class clworker implements Runnable{
	private Socket ts;
	private DataInputStream DataIn;
	private DataOutputStream DataOut;
	public clworker(Socket rs) {
		ts = rs;
		try {
			DataIn  = new DataInputStream(ts.getInputStream());
			DataOut = new DataOutputStream(ts.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void run() {
		while(true) {
			byte[] init = new byte[1];
			try {
				DataIn.read(init, 0, init.length);
				if (init[0] == 2) {
					System.out.println(new String(ReadSt()));
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private byte[] ReadSt() {
		byte[] dbuf = null;
		try {
			int s = 0;
			String revBuff = "";
			while((s=DataIn.read()) != 4) {
				revBuff += (char) s;
			}
			int revlen = Integer.parseInt(revBuff);
			dbuf = new byte[revlen];
			int bread = 0;
			int boff = 0;
			while(boff<revlen) {
				bread = DataIn.read(dbuf, boff, revlen-boff);
				boff+=bread;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbuf;
	
	}
	
}
