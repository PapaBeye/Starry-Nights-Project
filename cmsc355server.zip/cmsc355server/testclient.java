package cmsc355server;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.net.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.stream.*;
import java.util.concurrent.TimeUnit;


public class testclient {

	public static void main(String[] args) {
		try {
			Socket Cls = new Socket("localhost",20523);
			int numfs = 1;
			int i = 0;
			while(i!=numfs) {
				byte[] contents;
				byte[] RheartB = new byte[2000];
				Date dt = new Date();
				long ts = dt.getTime();
				FileOutputStream fos = new FileOutputStream("./revents/"+Long.toString(ts)+".json");
				InputStream is = Cls.getInputStream();
				OutputStream os = Cls.getOutputStream();
				is.read(RheartB, 0, RheartB.length);
				String hb = new String(RheartB, StandardCharsets.UTF_8);
				String[] phb =  hb.split("-");
				numfs = Integer.parseInt(phb[1]);
				hb = phb[0];
				String shb = hb + "-";
				byte[] heartB = shb.getBytes();
				int s = Integer.parseInt(hb);
				contents = new byte[s];
				System.out.println(s);
				os.write(heartB, 0, heartB.length);
				is.read(contents, 0, contents.length);
				fos.write(contents, 0, contents.length);
				System.out.println(new String(contents));
				fos.close();
				os.flush();
				i++;
				
			}
			Cls.close();
			
		} catch (IOException e) {
			e.printStackTrace();
			
		}
		
	}
}





/*
public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
	Socket sc = new Socket("localhost",20521);
	int i = 0;
	byte frb[] = new byte[2000];
	while (true) {
		InputStream is =  sc.getInputStream();
		is.read(frb, 0, frb.length);
		if (frb != null) {
			FileOutputStream fr = new FileOutputStream("./revents/Rf"+Integer.toString(i)+".json");
			fr.write(frb, 0, frb.length);
			i++;
		}
		frb = new byte[2000];
	}
}
*/
